<?
$ins = $_POST["ins"];
//�����ͺ��̽� �����ϱ�
$dbc = mysql_connect("localhost","linkhome","link25#$");
 mysql_select_db("linkhome",$dbc);



if(isset($_POST["ins"])) {
	//POST�� ���� �Է� ������ ���
	$arrUp = split("/",$ins);
	$id = $arrUp[0];
	$password = $arrUp[1];
	
	//$id = mysql_real_escape_string($ins);
	$id = mysql_real_escape_string($id);
	$password = mysql_real_escape_string($password);
	//$password = mysql_real_escape_string($dbc, trim($_POST['password']));
	//mysql_real_escape_string($dbc, trim($_POST['']));
	$query = "select * from member WHERE id = '$id' AND password = '$password'";
	$query_exec = mysql_query($query);
	$row = mysql_num_rows($query_exec);
	if($row){
			echo "yes";
	} else {
	    echo "no";
	}
	
	//	if(!empty($id))
		//{
		//$query = "SELECT * FROM member WHERE id = 'ID'"

		//$data = mysql_query($dbc, $query);
		//}

	mysql_close($dbc);
}	
?>